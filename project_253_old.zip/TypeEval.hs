module TypeEval where

import Language.Haskell.Exts.Simple
import Data.List
import Debug.Trace

import Datatypes


-- Methods used within type evaluation
initalizeContext :: () -> OverallContext
initalizeContext () = 
    let trueBool = (Ident "True", Concrete BoolType) in
    let falseBool = (Ident "False", Concrete BoolType) in
    let env = [trueBool, falseBool] in
    OverallContext env (GlobalContext [] [])
    
    
genVarType :: GlobalContext -> (AllTypes, GlobalContext)
genVarType global_context =
    case global_context of
        (GlobalContext usedVarNames contraints) ->
            let returnFun = (\new -> (new, (GlobalContext (new:usedVarNames) contraints))) in 
                case usedVarNames of
                    [] ->  returnFun (TypeVar 0)
                    (TypeVar lastNew):other -> returnFun (TypeVar (lastNew + 1))
        (ErrorContext errMsg) -> (Error, ErrorContext errMsg)

addConstraint :: GlobalContext -> (AllTypes, AllTypes) -> GlobalContext 
addConstraint global_context rule = 
    case global_context of
        GlobalContext varTypeNames contraints -> GlobalContext varTypeNames (rule:contraints)  
        ErrorContext errMsg -> ErrorContext errMsg



getType :: Exp -> OverallContext -> (AllTypes, GlobalContext)  
getType expr context = let (OverallContext env global_context) = context in
    case global_context of
        ErrorContext errMsg -> (Error, ErrorContext errMsg)
        otherwise ->
            case expr of
                Lit literal -> 
                    (case literal of
                        Int val -> (Concrete IntType, global_context)
                        String val -> (Concrete StringType, global_context)
                        otherwise -> trace ("Bad literal type") (Error, ErrorContext "Undefined literal type"))
                Con (UnQual (Ident boolStr)) -> (Concrete BoolType, global_context)
                --con 
                Var varNam -> ctVar varNam context
                List exprList -> ctList exprList context
                InfixApp expr1 op expr2 -> ctInfixOpType expr1 op expr2 context
                If expr1 expr2 expr3 -> tIf expr1 expr2 expr3 context --tIf expr1 expr2 expr3 context
                Let (BDecls binds) expr1 -> ctLet binds expr1 context 
                Lambda [patts] body -> tLambda (Lambda [patts] body) context--tLambdaMultInputs patts body context
                App lambda input -> tApp lambda input context
                Case expr1 altlist -> (ctCaselist expr1 altlist context)
                Paren expr1 -> getType expr1 context
                otherwise -> trace ("Parsing error, term not recognized") (Error, ErrorContext "Parsing error, term not recognized")        
        
        
-- Type Rules

-- --tLambda patt body = Error 
    -- --pVar
-- -- Need to correctly figure out input types
-- tLambdaMultInputs :: [Pat] -> Exp -> OverallContext -> (AllTypes, GlobalContext) 
-- tLambdaMultInputs patts body context = 
    -- let curriedLambdas = (curryLambdas patts body) in
        -- tLambda curriedLambdas context
        
    
-- curryLambdas :: [Pat] -> Exp -> Exp
-- curryLambdas patts body = 
    -- case patts of
        -- patt:[] -> (Lambda [patt] body) --(getType body context)
        -- patt:other_patts -> -- Want to nest the lambdas
            -- --curryLambdas other_patts (Lambda [patt] body)
            -- Lambda [patt] (curryLambdas other_patts body)
    
-- tLambda :: Exp -> OverallContext -> (AllTypes, GlobalContext) 
-- tLambda pattBody context = 
    -- case pattBody of 
        -- (Lambda (patt:[]) body) ->
            -- let (PVar id) = patt in 
            -- let (OverallContext env global_context) = context in 
            -- let (typeVar, new_global_context) = (genVarType global_context) in
            -- let (bodyType, bodyContext) = (getType body (OverallContext ((id, typeVar):env) new_global_context)) in
                -- ((ArrowType typeVar bodyType), bodyContext)

-- -- Based on textbook's CT-ABSINF                
-- tApp :: Exp -> Exp -> OverallContext -> (AllTypes, GlobalContext) 
-- tApp lambda input context = 
    -- let (OverallContext env global_context) = context in
        -- let (lambdaType, global_context_2) = (getType lambda context) in
        -- let (inputType, global_context_3) = (getType input (OverallContext env global_context_2)) in
        -- let (resTypeVar, res_global_context) = (genVarType global_context_3) in
        -- let newrule = (lambdaType,(ArrowType inputType resTypeVar)) in
        -- let res_context = (addConstraint res_global_context newrule) in
            -- (resTypeVar, res_context)
--unify context pVar = 

tLambda :: Exp -> OverallContext -> (AllTypes, GlobalContext) 
tLambda pattBody context = 
    case pattBody of 
        (Lambda (patt:[]) body) ->
            let (PVar id) = patt in 
            let (OverallContext env global_context) = context in 
            let (inTypeVar, new_global_context) = (genVarType global_context) in
            let (bodyType, bodyContext) = (getType body (OverallContext ((id, inTypeVar):env) new_global_context)) in
                ((ArrowType inTypeVar bodyType), bodyContext)

-- Based on textbook's CT-ABSINF                
tApp :: Exp -> Exp -> OverallContext -> (AllTypes, GlobalContext) 
tApp lambda input context = 
    let (OverallContext env global_context) = context in
        let (lambdaType, global_context_2) = (getType lambda context) in
        let (inputType, global_context_3) = (getType input (OverallContext env global_context_2)) in
        let (resTypeVar, res_global_context) = (genVarType global_context_3) in
        let newrule = (lambdaType,(ArrowType inputType resTypeVar)) in
        let res_context = (addConstraint res_global_context newrule) in
            (resTypeVar, res_context)





tIf :: Exp -> Exp -> Exp -> OverallContext -> (AllTypes, GlobalContext) 
tIf expr1 expr2 expr3 context = 
    let (OverallContext env global_context) = context in
    let (condType, global_context_1) = (getType expr1 context) in
    let (iftrueType, global_context_2) = (getType expr2 (OverallContext env global_context_1)) in
    let (iffalseType, global_context_3) = (getType expr3 (OverallContext env global_context_2)) in
    let newrule1 = (condType, (Concrete BoolType)) in
    let newrule2 = (iftrueType, iffalseType) in
    let res_context = (addConstraint (addConstraint global_context_3 newrule1) newrule2) in
        (iftrueType, res_context)

ctLet :: [Decl] -> Exp -> OverallContext -> (AllTypes, GlobalContext)
ctLet binds expr context = 
    --let (funName, binds) = trace ("orig: " ++ show origbinds ++ ".\n") (desugarLetFuns origbinds) in
    --let newExpr = trace ("desugared: " ++ show binds ++ ".\n") (subBinds binds expr) in
    let (OverallContext env global_context) = context in
    --let (_, global_context_2) = (ctBinds binds context) in
    --(getType expr (OverallContext env global_context_2))
    let (_, overall_context_2) = (ctBinds binds context) in
        --trace ("ctLet called..." ++ show overall_context_2) (getType expr overall_context_2)
        (getType expr overall_context_2)

--ctBinds :: [Decl] -> OverallContext -> (AllTypes, GlobalContext) 
ctBinds :: [Decl] -> OverallContext -> (AllTypes, OverallContext)   
ctBinds binds context = let (OverallContext env global_context) = context in
    case binds of
        [bind] -> ctBind bind context
        bind:tail -> 
            let (bType, overall_context_2) = (ctBind bind context) in 
                ctBinds tail overall_context_2  --print "other-----"
        otherwise -> trace ("ctBind issue") (Error, (OverallContext env (ErrorContext "Empty binding")))
                  
    
--ctBind :: Decl -> OverallContext -> (AllTypes, GlobalContext)   
ctBind :: Decl -> OverallContext -> (AllTypes, OverallContext)   
ctBind bind context = let (OverallContext env global_context) = context in
    case bind of
        FunBind [matching] -> trace ("Function binding not impl") (Error, (OverallContext env (ErrorContext "...function binding.....")))
        PatBind (PVar ident) (UnGuardedRhs rhs) Nothing -> 
            let (rhsTypeVar, global_context_2) = genVarType global_context in
            let (rhsType, global_context_3) = getType rhs (OverallContext ((ident, rhsTypeVar):env) global_context_2) in 
            let rule = (rhsTypeVar, rhsType) in
            let global_context_4 = (addConstraint global_context_3 rule) in
                --trace ("Add binding " ++ show ident ++ " to " ++ show rhsType) (rhsType, (OverallContext ((ident, rhsType):env) global_context_4))
                (rhsType, (OverallContext ((ident, rhsType):env) global_context_4))
        otherwise -> (Error, (OverallContext env (ErrorContext ("Unrecognized binding: " ++ show bind)))) --print "otherOther..."
 
-- tMatching matching = case matching of
    -- Match name [pat] rhs (Nothing) -> print "matching1..."
    -- Match name [pat] rhs (Just binds) -> print "matching2..."
    -- InfixMatch pat name [patt] rhs (Just binds) -> print "matching3..."
    -- InfixMatch pat name [patt] rhs (Nothing) -> print "matching4..."
 
 
 

ctInfixOpType :: Exp -> QOp -> Exp -> OverallContext -> (AllTypes, GlobalContext)   
ctInfixOpType expr1 op expr2 context = 
    case op of
        QVarOp (UnQual opp) ->  
            case opp of
                Symbol "+" -> ctBoolArithExp expr1 expr2 (Concrete IntType) context
                Symbol "-" -> ctBoolArithExp expr1 expr2 (Concrete IntType) context
                Symbol "*" -> ctBoolArithExp expr1 expr2 (Concrete IntType) context
                Symbol "/" -> ctBoolArithExp expr1 expr2 (Concrete IntType) context
                Symbol "<" -> ctBoolArithExp expr1 expr2 (Concrete IntType) context
                Symbol "==" -> ctEqExp expr1 expr2 context
                Symbol "||" -> ctBoolArithExp expr1 expr2 (Concrete BoolType) context
                Symbol "&&" -> ctBoolArithExp expr1 expr2 (Concrete BoolType) context
                Symbol "++" -> ctBoolArithExp expr1 expr2 (Concrete StringType) context
                otherwise -> trace ("Unrecognized binary op") (Error, ErrorContext ("Unrecognized binary op" ++ show opp)) 
        QConOp (Special Cons) -> ctConsExp expr1 expr2 context
        --Special Cons -> ctConsExp expr1 expr2 context
        otherwise -> trace ("ctInfixOpType failed") (Error, ErrorContext ("Unrecognized binary op" ++ show op)) 

    -- env will be a lookup [(key, value)]
    

ctVar :: QName -> OverallContext -> (AllTypes, GlobalContext)
ctVar xIn context =
    let (UnQual x) = xIn in
        case context of 
        (OverallContext env global_context) ->
            case (lookup x env) of
                Nothing -> (Error, ErrorContext ("Undefined var: " ++ show x)) -- Actually want to create type variable??
                Just t -> (t, global_context)
        --OverallErrorContext -> (Error "ctVar in error context", ErrorContext)
 

ctEqExp :: Exp -> Exp -> OverallContext -> (AllTypes, GlobalContext) 
ctEqExp in1 in2 context = let retType = (Concrete BoolType) in
    case context of
        (OverallContext env global_context) ->
            let (t1, global_context_1) = (getType in1 context) in
            let (t2, global_context_2) = (getType in2 (OverallContext env global_context_1))  
                in (retType, (addConstraint global_context_2 (t1, t2)))
        --OverallErrorContext -> (Error "ctEqExp in error context" , ErrorContext) 
        
ctList :: [Exp] -> OverallContext -> (AllTypes, GlobalContext)        
ctList exprList context = let (OverallContext env global_context) = context in
    case exprList of
        -- [] ->  trace ("NULLL list...\n") (EmptyListType, global_context) 
        [] -> 
            let (typeVar, global_context_1) = genVarType global_context in
                (ListType typeVar, global_context_1)
        [exp] -> 
            let (t1, global_context_1) = (getType exp context) in
                --trace ("1 elm list\n") (ListType t1, global_context_1)
                (ListType t1, global_context_1)
        exp:tail -> 
            let (t1, global_context_1) = (getType exp context) in
            let (t2, global_context_2) = (ctList tail (OverallContext env global_context_1)) in
                (t2, (addConstraint global_context_2 (t2, ListType t1)))
 
ctBoolArithExp :: Exp -> Exp -> AllTypes -> OverallContext -> (AllTypes, GlobalContext) 
ctBoolArithExp in1 in2 cType context = case context of
    (OverallContext env global_context) ->
        let (t1, global_context_1) = (getType in1 context) in
            let (t2, global_context_2) = (getType in2 (OverallContext env (addConstraint global_context_1 (t1, cType))))  
                in (cType, (addConstraint global_context_2 (t2, cType)))
    --OverallErrorContext -> (Error "ctBoolArithExp in error context" , ErrorContext) 
 
ctConsExp :: Exp -> Exp -> OverallContext -> (AllTypes, GlobalContext)  
ctConsExp in1 in2 context = case context of
    (OverallContext env global_context) ->
        let (t1, global_context_1) = (getType in1 context) in
        let (t2, global_context_2) = (getType in2 (OverallContext env global_context_1)) in
            ((ListType t1), (addConstraint global_context_2 (t2, (ListType t1))))

-- WIP HERE!!!!!!!!!!!_______ 
ctCaselist :: Exp -> [Alt] -> OverallContext -> (AllTypes, GlobalContext)
ctCaselist expr altList context = 
    let (OverallContext env global_context) = context in
    let (exprType, global_context_1) = (getType expr context) in 
    case altList of
        [hd] ->
            --trace ("One elem. " ++ show expr) (ctCase exprType hd (OverallContext env global_context_1))
            (ctCase exprType hd (OverallContext env global_context_1))
        hd:tail -> 
            let (hdType, global_context_2) = ctCase exprType hd (OverallContext env global_context_1) in
            let (tailType, global_context_3) = ctCaselist expr tail (OverallContext env global_context_2) in
            let newrule = (hdType, tailType) in
            let global_context_4 = (addConstraint global_context_3 newrule) in
                (hdType, global_context_4)
        --otherwise -> (Error "misformed case stmt", ErrorContext)
        
    
 
ctPat :: Pat -> OverallContext -> (AllTypes, OverallContext)   
ctPat patt context = let (OverallContext env global_context) = context in
    case patt of
        (PList []) -> --(EmptyListType, context)
            let (typeVar, global_context_1) = genVarType global_context in
                trace (show patt) (ListType typeVar, OverallContext env global_context_1)
        (PList [patt1]) -> 
            let (p1Type, new_context) = (ctPat patt1 context) in
                trace (show patt) ((ListType p1Type), new_context)
        (PInfixApp patt1 (Special Cons) patt2) ->
            let (p1Type, context_1) = (ctPat patt1 context) in
            let (p2Type, (OverallContext env2 global_context_2)) = (ctPat patt2 context_1) in
            let newrule = (p2Type, ListType p1Type) in
            let new_global_context = addConstraint global_context_2 newrule in
                ((ListType p1Type), (OverallContext env2 new_global_context))
        (PLit sign literal) ->  
            case literal of
                Int val -> (Concrete IntType, context)
                String val -> (Concrete IntType, context)
                otherwise -> (Error, (OverallContext env (ErrorContext ("Bad literal pattern " ++ show literal))))
        (PVar id) -> trace ("pVar: " ++ show patt) ctPVar id context
        PWildCard -> trace "wildcard"  ctWildCard context
        otherwise -> trace "otherpattErr" (Error, (OverallContext env (ErrorContext ("Unmatched pattern: " ++ show patt))))
 
ctWildCard context =
    case context of 
        (OverallContext env global_context) ->
            let (typeVar, global_context_1) = (genVarType global_context) in
                (typeVar, (OverallContext env global_context_1))
 
ctPVar varName context = 
    case context of 
        (OverallContext env global_context) ->
            let (typeVar, global_context_1) = (genVarType global_context) in
            let newenv = (varName, typeVar):env in
                (typeVar, (OverallContext newenv global_context_1))
 
-- See pg 132 (Need sum types first)
-- Do the binding stuff, then evaluate RHS 
ctCase :: AllTypes -> Alt -> OverallContext -> (AllTypes, GlobalContext) 
ctCase exprType alt context = (ctCase2 exprType alt context)
                            --trace ("ALT: " ++ show alt) (ctCase2 exprType alt context)
   
ctCase2 exprType alt context = let (OverallContext env global_context) = context in
    let (Alt pat (UnGuardedRhs rhs) (Nothing)) = alt in
    let (patType, (OverallContext env_1 global_context_1)) = (ctPat pat context) in
    let newrule = (patType, exprType) in
    let global_context_2 = (addConstraint global_context_1 newrule) in
        (getType rhs (OverallContext env_1 global_context_2))

