{-# LANGUAGE TemplateHaskell #-}

--sum x = x / 1
--let foo f y = f + y in let yada x = foo x 1 in yada  -- Test function binding
--let foo x y  c= x + y in let z = foo in z
-- let foo = (\x y z -> x == y) in foo 1 3 -- NEEDS FIXING (Issue in subbing in final contrainsts)
--let x = 5 in let y = 3 in x - y + u  -- *** Exception: main.hs:(46,37)-(47,89): Non-exhaustive patterns in case
--(\x -> if False then x else 5 - 1 + 2) "hi"
-- \q -> let x = 3 in let y = q in let z = x + y in q -- Make sure contraints added for binding expr's, even if not used...
-- \x -> x + 5
--True

-- let foo x = case x of          -- Show that let allows parametric functions
                -- [] -> "empty"
                -- h:t -> "non-empty"
            -- in (if True then foo [1, 2, 3] else foo ["r"])
                 
--(\x y z -> [y + z, x]) 
--let foo x = x in let bar y z = foo y + z in 7 
--let foo = \x y -> 1 in 7
--let foo x y = 1 in 2
-- let foo = (\x -> 1) in 7

-- let x = "hi" in 
    -- if (x == 4) then 
        -- let x = 4 in x
    -- else
        -- let x = 6 in x
  
--let foo x = if (x == 0) then 1 else foo (x - 1) in foo
--Nothing

--[7 + u  
  
--let hello x = 1 in 4 
[u + 3] 
 
-- let foo a = 
        -- case a of
            -- [] -> 0
            -- h:t -> 1 + (foo t)
        -- in foo 
        
["hi" + 3]

\x y -> (x == y)

6 - 2

(\x y -> x ++ y ) "ji" "fdui"

let foo x y = (x == y) in (foo "hi" "bye") || (foo 3 3)

\x y -> (x == y)

[1, 2, 2 - 1 + 4]

(\x y -> x + y) 4 5

6 - 2

case [1, 2, 3] of
    [] -> "Emp"
    [2] -> "yo"
    otherwise -> "ddd"



-- Nothing
-- ORIG EXPR: Paren () (App () (Con () (UnQual () (Ident () "Just"))) (Lit () (Int () 7 "7")))

-- Ex parametric funcion
--let foo x y = (x == y) in (foo "hi" "bye") && (foo 3 3)

-- [1, 2, 3]

-- [(TypeVar 0,Concrete IntType),
 -- (ArrowType (TypeVar 1) (Concrete BoolType),TypeVar 2),
 -- (TypeVar 1,Concrete IntType)]

 -- T0 = Int,
 -- T1 -> Bool = T2
 -- T1 = Int
 
 -- Output = T2 = 
 
 
 --let foo x = body
 --let foo = \x -> body