module Eval where

import Language.Haskell.Exts.Simple
import Data.List
import Debug.Trace

import Preprocess
import Datatypes


eval :: Exp -> Value 
eval expr  = 
    case expr of
        Lit literal -> 
            case literal of
                Int val -> IntVal val
                String val -> StringVal val
                otherwise -> trace ("Bad literal type") (ErrValue "err")
        Con (UnQual (Ident boolStr)) -> 
            case boolStr of
                "True" -> BoolVal True --(Concrete BoolType, global_context)
                otherwise -> BoolVal False
        List exprList -> evList exprList
        InfixApp expr1 op expr2 -> eInfixOpType expr1 op expr2
        If expr1 expr2 expr3 -> eIf expr1 expr2 expr3
        Let (BDecls [bind]) expr1 -> eLet bind expr1
        Lambda [patt] body -> eLambda patt body
        App lambda input -> eApp lambda input
        Case expr1 altlist -> (eCaselist expr1 altlist)
        Paren expr1 -> eval expr1
        otherwise -> trace ("Parsing error, term not recognized") (ErrValue "Not handled")       
        


eLambda patt body = 
    let (PVar (Ident id)) = patt in
        LambdaVal id body
        
-- Based on textbook's CT-ABSINF                
eApp :: Exp -> Exp -> Value
eApp lambda input = 
    let vLambda = (eval lambda) in
    case vLambda of
        (LambdaVal id body) ->
            let lambda_eval = (subExpr id input body) in
                (eval lambda_eval)
        otherwise -> trace ("lambda is: " ++ (show lambda)) ErrValue ("lambda is: " ++ (show lambda))



eIf :: Exp -> Exp -> Exp -> Value 
eIf expr1 expr2 expr3 = 
    let condition = (eval expr1) in
    case condition of
        (BoolVal True) -> (eval expr1)
        otherwise -> (eval expr2)


eLet :: Decl -> Exp -> Value
eLet bind expr = 
     case bind of
        (PatBind (PVar (Ident id)) (UnGuardedRhs rhs) _) ->
            let let_eval = (subExpr id rhs expr) in
                (eval let_eval)
        otherwise -> (ErrValue "blahblha")
        
-- ctLet :: [Decl] -> Exp -> OverallContext -> (AllTypes, GlobalContext)
-- ctLet binds expr context = 
    -- let (OverallContext env global_context) = context in
    -- let (_, overall_context_2) = (ctBinds binds context) in
        -- (getType expr overall_context_2)

-- ctBinds :: [Decl] -> OverallContext -> (AllTypes, OverallContext)   
-- ctBinds binds context = let (OverallContext env global_context) = context in
    -- case binds of
        -- [bind] -> ctBind bind context
        -- bind:tail -> 
            -- let (bType, overall_context_2) = (ctBind bind context) in 
                -- ctBinds tail overall_context_2  --print "other-----"
        -- otherwise -> trace ("ctBind issue") (Error, (OverallContext env (ErrorContext "Empty binding")))
                  
      
-- ctBind :: Decl -> OverallContext -> (AllTypes, OverallContext)   
-- ctBind bind context = let (OverallContext env global_context) = context in
    -- case bind of
        -- FunBind [matching] -> trace ("Function binding not impl") (Error, (OverallContext env (ErrorContext "...function binding.....")))
        -- PatBind (PVar ident) (UnGuardedRhs rhs) Nothing -> 
            -- let (rhsTypeVar, global_context_2) = genVarType global_context in
            -- let (rhsType, global_context_3) = getType rhs (OverallContext ((ident, rhsTypeVar):env) global_context_2) in 
            -- let rule = (rhsTypeVar, rhsType) in
            -- let global_context_4 = (addConstraint global_context_3 rule) in
                -- (rhsType, (OverallContext ((ident, rhsType):env) global_context_4))
        -- otherwise -> (Error, (OverallContext env (ErrorContext ("Unrecognized binding: " ++ show bind)))) --print "otherOther..."


eInfixOpType :: Exp -> QOp -> Exp -> Value   
eInfixOpType expr1 op expr2 =
    let val1 = (eval expr1) in
    let val2 = (eval expr2) in
    case op of
        QVarOp (UnQual opp) ->
            case (val1, val2) of
                (IntVal v1, IntVal v2) ->
                    case opp of
                        Symbol "+" -> IntVal (v1 + v2) 
                        Symbol "-" -> IntVal (v1 - v2) 
                        Symbol "*" -> IntVal (v1 * v2) 
                        --Symbol "/" -> IntVal (v1 / v2) 
                        Symbol "<" -> BoolVal (v1 < v2) 
                        Symbol "==" -> BoolVal (v1 == v2)
                        otherwise -> trace ("Unrecognized binary op") (ErrValue "dfl")                        
                (BoolVal v1, BoolVal v2) ->
                    case opp of
                        Symbol "||" -> BoolVal (v1 || v2)
                        Symbol "&&" -> BoolVal (v1 && v2)
                        Symbol "==" -> BoolVal (v1 == v2)
                        otherwise -> trace ("Unrecognized binary op") (ErrValue "dfl")
                (StringVal v1, StringVal v2) ->
                    case opp of
                        Symbol "++" -> StringVal (v1 ++ v2)
                        Symbol "==" -> BoolVal (v1 == v2)
                        otherwise -> trace ("Unrecognized binary op") (ErrValue "dfl")
        -- QConOp (Special Cons) ->
            -- val1:val2
        --Special Cons -> ctConsExp expr1 expr2 context
        otherwise -> trace ("ctInfixOpType failed") (ErrValue "dfl")

    -- env will be a lookup [(key, value)]
    

-- ctVar :: QName -> OverallContext -> (AllTypes, GlobalContext)
-- ctVar xIn context =
    -- let (UnQual x) = xIn in
        -- case context of 
        -- (OverallContext env global_context) ->
            -- case (lookup x env) of
                -- Nothing -> (Error, ErrorContext ("Undefined var: " ++ show x)) -- Actually want to create type variable??
                -- Just t -> (t, global_context)
        -- --OverallErrorContext -> (Error "ctVar in error context", ErrorContext)
 

-- ctEqExp :: Exp -> Exp -> OverallContext -> (AllTypes, GlobalContext) 
-- ctEqExp in1 in2 context = let retType = (Concrete BoolType) in
    -- case context of
        -- (OverallContext env global_context) ->
            -- let (t1, global_context_1) = (getType in1 context) in
            -- let (t2, global_context_2) = (getType in2 (OverallContext env global_context_1))  
                -- in (retType, (addConstraint global_context_2 (t1, t2)))
        -- --OverallErrorContext -> (Error "ctEqExp in error context" , ErrorContext) 
 
evList :: [Exp] -> Value
evList exprList = 
    case exprList of
        [] -> ListVal []
        h:tl -> ListVal ((eval h):[(evList tl)])
-- ctList :: [Exp] -> OverallContext -> (AllTypes, GlobalContext)        
-- ctList exprList context = let (OverallContext env global_context) = context in
    -- case exprList of
        -- -- [] ->  trace ("NULLL list...\n") (EmptyListType, global_context) 
        -- [] -> 
            -- let (typeVar, global_context_1) = genVarType global_context in
                -- (ListType typeVar, global_context_1)
        -- [exp] -> 
            -- let (t1, global_context_1) = (getType exp context) in
                -- --trace ("1 elm list\n") (ListType t1, global_context_1)
                -- (ListType t1, global_context_1)
        -- exp:tail -> 
            -- let (t1, global_context_1) = (getType exp context) in
            -- let (t2, global_context_2) = (ctList tail (OverallContext env global_context_1)) in
                -- (t2, (addConstraint global_context_2 (t2, ListType t1)))
 
eCaselist :: Exp -> [Alt] -> Value
eCaselist expr altList = 
    let evaled_expr = (eval expr) in ...
    case altList of 
        [hd] ->  -- does this pattern match?
        hd:tl -> -- if not keep on going...
 

-- -- WIP HERE!!!!!!!!!!!_______ 
-- ctCaselist :: Exp -> [Alt] -> OverallContext -> (AllTypes, GlobalContext)
-- ctCaselist expr altList context = 
    -- let (OverallContext env global_context) = context in
    -- let (exprType, global_context_1) = (getType expr context) in 
    -- case altList of
        -- [hd] ->
            -- --trace ("One elem. " ++ show expr) (ctCase exprType hd (OverallContext env global_context_1))
            -- (ctCase exprType hd (OverallContext env global_context_1))
        -- hd:tail -> 
            -- let (hdType, global_context_2) = ctCase exprType hd (OverallContext env global_context_1) in
            -- let (tailType, global_context_3) = ctCaselist expr tail (OverallContext env global_context_2) in
            -- let newrule = (hdType, tailType) in
            -- let global_context_4 = (addConstraint global_context_3 newrule) in
                -- (hdType, global_context_4)
        -- --otherwise -> (Error "misformed case stmt", ErrorContext)
        
    
 
-- ctPat :: Pat -> OverallContext -> (AllTypes, OverallContext)   
-- ctPat patt context = let (OverallContext env global_context) = context in
    -- case patt of
        -- (PList []) -> --(EmptyListType, context)
            -- let (typeVar, global_context_1) = genVarType global_context in
                -- trace (show patt) (ListType typeVar, OverallContext env global_context_1)
        -- (PList [patt1]) -> 
            -- let (p1Type, new_context) = (ctPat patt1 context) in
                -- trace (show patt) ((ListType p1Type), new_context)
        -- (PInfixApp patt1 (Special Cons) patt2) ->
            -- let (p1Type, context_1) = (ctPat patt1 context) in
            -- let (p2Type, (OverallContext env2 global_context_2)) = (ctPat patt2 context_1) in
            -- let newrule = (p2Type, ListType p1Type) in
            -- let new_global_context = addConstraint global_context_2 newrule in
                -- ((ListType p1Type), (OverallContext env2 new_global_context))
        -- (PLit sign literal) ->  
            -- case literal of
                -- Int val -> (Concrete IntType, context)
                -- String val -> (Concrete IntType, context)
                -- otherwise -> (Error, (OverallContext env (ErrorContext ("Bad literal pattern " ++ show literal))))
        -- (PVar id) -> trace ("pVar: " ++ show patt) ctPVar id context
        -- PWildCard -> trace "wildcard"  ctWildCard context
        -- otherwise -> trace "otherpattErr" (Error, (OverallContext env (ErrorContext ("Unmatched pattern: " ++ show patt))))
 
-- ctWildCard context =
    -- case context of 
        -- (OverallContext env global_context) ->
            -- let (typeVar, global_context_1) = (genVarType global_context) in
                -- (typeVar, (OverallContext env global_context_1))
 
-- ctPVar varName context = 
    -- case context of 
        -- (OverallContext env global_context) ->
            -- let (typeVar, global_context_1) = (genVarType global_context) in
            -- let newenv = (varName, typeVar):env in
                -- (typeVar, (OverallContext newenv global_context_1))
 
-- -- See pg 132 (Need sum types first)
-- -- Do the binding stuff, then evaluate RHS 
-- ctCase :: AllTypes -> Alt -> OverallContext -> (AllTypes, GlobalContext) 
-- ctCase exprType alt context = (ctCase2 exprType alt context)
                            -- --trace ("ALT: " ++ show alt) (ctCase2 exprType alt context)
   
-- ctCase2 exprType alt context = let (OverallContext env global_context) = context in
    -- let (Alt pat (UnGuardedRhs rhs) (Nothing)) = alt in
    -- let (patType, (OverallContext env_1 global_context_1)) = (ctPat pat context) in
    -- let newrule = (patType, exprType) in
    -- let global_context_2 = (addConstraint global_context_1 newrule) in
        -- (getType rhs (OverallContext env_1 global_context_2))

