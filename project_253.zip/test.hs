{-# LANGUAGE TemplateHaskell #-}

 
let foo x = x in let bar y z = foo y + z in bar 1 7 
let foo = \x y -> 1 in 7
--let foo x y = 1 in 2
-- let foo = (\x -> 1) in 7

-- let x = "hi" in 
    -- if (x == 4) then 
        -- let x = 4 in x
    -- else
        -- let x = 6 in x
  
let foo x = if (x == 0) then 1 else foo (x - 1) in foo
--Nothing

--[7 + u  
  
--let hello x = 1 in 4 
[u + 3] 
 
let len a = case a of
                [] -> 0
                h:t -> 1 + (len t)
            in len [1, 2, 4, 5]
            
let len a = case a of
                [] -> 0
                h:t -> 1 + (len t)
            in len ["a", "b", "c"]
            
let len a = case a of
                [] -> 0
                h:t -> 1 + (len t)
            in (len [1, 2, 3, 4]) + (len ["a", "b", "c"])
            
( 5 < 6 )
        
["hi" + 3]

let f = 5 in (2:[1-f, 4])

\x y -> (x == y)

6 - 2

(\x y -> x ++ y ) "ji" "fdui"

let baz x y = (x == y) in (baz "hi" "bye") || (baz 3 3)

\x y -> (x == y)

[1, 2, 2 - 1 + 4]

(\x y -> x + y) 4 5

6 - 2

True

False

case [6-5, 2] of
    [1, 2] -> "em"
    otherwise -> "NOO"

case [2] of
    [] -> "Emp"
    [2] -> "yo"
    otherwise -> "ddd"



-- Nothing
-- ORIG EXPR: Paren () (App () (Con () (UnQual () (Ident () "Just"))) (Lit () (Int () 7 "7")))

-- Ex parametric funcion
--let foo x y = (x == y) in (foo "hi" "bye") && (foo 3 3)

-- [1, 2, 3]

-- [(TypeVar 0,Concrete IntType),
 -- (ArrowType (TypeVar 1) (Concrete BoolType),TypeVar 2),
 -- (TypeVar 1,Concrete IntType)]

 -- T0 = Int,
 -- T1 -> Bool = T2
 -- T1 = Int
 
 -- Output = T2 = 
 
 
 --let foo x = body
 --let foo = \x -> body