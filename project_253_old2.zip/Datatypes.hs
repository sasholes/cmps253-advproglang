-- CMPS 253, Fall 2017
-- Sara Sholes, 1153681
-- Final Project

module Datatypes where

import Language.Haskell.Exts.Simple

data Value = IntVal Integer
    | StringVal String
    | BoolVal Bool
    | ListVal [Value]
    | LambdaVal String Exp
    | ErrValue String
     deriving (Show)


data ConcreteTypes = IntType
    | BoolType
    | StringType
     deriving (Eq) --, Show)
      
data AllTypes = Concrete ConcreteTypes
    | Error
    | TypeVar Int
    | ParamType Int
    | ArrowType AllTypes AllTypes
    | ListType AllTypes
      deriving (Eq)
      

data GlobalContext = 
    GlobalContext [AllTypes] [(AllTypes, AllTypes)]
    | ErrorContext String
     deriving (Show)

data OverallContext = 
    OverallContext [(Name, AllTypes)] GlobalContext  -- Note change Name to a string
    -- | OverallErrorContext
     deriving (Show)
     
data UnifyResult = 
    TypeVarAssignment [(AllTypes, AllTypes)]
    | UnificationErr String
     deriving (Show)
 

instance Show AllTypes where 
    show allType =
        case allType of
            Concrete concreteType ->
                case concreteType of
                    IntType -> "Int"
                    BoolType -> "Bool"
                    StringType -> "String"
            ArrowType inType outType ->
                (show inType) ++ " -> " ++ (show outType)
            ListType elemType ->
                "[" ++ (show elemType) ++ "]"
            ParamType idNum ->
                "T_" ++ (show idNum)
            TypeVar idNum ->
                "X_" ++ (show idNum)
            Error ->
                "*ERROR*"