main =  
    let len a = case a of
                    [] -> 0
                    h:t -> 1 + (len t)
                    in print ((len [1, 2, 3, 4]) + (len ["a", "b", "c"]))